MK3 Force Feedback driver v1.00
==============================================
			Compatible with Gens32 Surreal v1.28 LDU+ or heigher


How to use:
Copy this driver to Gens32's folder.Rename it to your rom's name(not the zip folder's name) if necessary.

Function:
Force Feedback when player was hited,or player pressed a key in battle;

Copyright: 2007 ACOMPAL
Released By DarkDancer
Ser: AC-2007-01-03-01
Ver: WE(world & English)

