Kiyo Media Player v1.00
============================================
ACOMPAL HOME PAGE: http://gens32.emubase.de


//=========================
//Introduction
//====================
This media player is use dshow.Our target is made a music player
which cost less system resource,but have basal functins,such as play
list.




//============================================
//More Introduction about ACOMPAL Software 
//=========================================


//////////////////////
//Gens32 Surreal
///////////////////
Gens32 Surreal is the craziest SEGA Genesis/Mega-Drive/Sega-CD/
Mega-CD/32X systems emulator.


//////////////////////////////////
//Virtual Space Controller
///////////////////////////
As the name,Virtual Sapce Controller is a 'Virtual Controller'.
So,what is it? This Motorcycle VSC for example.
With your cameram,you can make your chair became a ''motorbike".
You just ride it to join a motorbike racing in game.It's really cool,isn't?

