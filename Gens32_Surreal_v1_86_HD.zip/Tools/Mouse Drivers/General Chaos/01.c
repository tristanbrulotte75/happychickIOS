#SetPin 57996 58000
#SetArea 0 500 0 500
#DefineButton 1 2 3

