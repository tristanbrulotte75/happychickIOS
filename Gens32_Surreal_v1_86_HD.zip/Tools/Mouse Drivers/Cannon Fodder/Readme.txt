Cannon Fodder (E) [!] Mouse driver v1.00
==============================================
			Compatible with Gens32 Surreal v1.20 or heigher


How to use:
Copy this driver to Gens32's folder.Rename it to your rom's name(not the zip folder's name) if necessary.

The mouse's key define as followes:

Left Button:
Move To

Midle Button:
Start

Right Button:
Shot


