# SegaGenesisController
Sega genesis (mega drive 2) controller protocol implementation for Arduino

Thanx to the article

http://jonthysell.com/2014/07/26/reading-sega-genesis-controllers-with-arduino/

Here comes more usable and configurable implementation of the above idea.
