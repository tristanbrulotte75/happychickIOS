#ifndef _FRAME_SKIP_H
#define _FRAME_SKIP_H


void reset_frame_skip(void);
int frame_skip(void);


#endif
