#ifndef __MMUHACK__
#define __MMUHACK__

#ifdef __cplusplus
extern "C" {
#endif

extern int mmuhack(void);
extern int mmuunhack(void);

#ifdef __cplusplus
}
#endif

#endif /* __MMUHACK__ */
