//
//  ScreenView.h
//  SNES4iPad
//
//  Created by Yusef Napora on 5/15/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScreenView : UIView <UIActionSheetDelegate> {

}


@end
