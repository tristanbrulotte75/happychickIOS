#!/bin/bash
exec "$(dirname "$0")"/SNES-HD &> /tmp/snes-hd.log
