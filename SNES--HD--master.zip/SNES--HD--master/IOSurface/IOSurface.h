

#ifndef _IOSURFACE_H
#define _IOSURFACE_H 1

#include <Availability2.h>
#define IOSFC_AVAILABLE_STARTING(mac, iphone) __OSX_AVAILABLE_STARTING(__MAC_10_6, __IPHONE_3_0)

#include <sys/cdefs.h>
#include <CoreFoundation/CFBase.h>

#include "IOSurfaceAPI.h"

#endif
